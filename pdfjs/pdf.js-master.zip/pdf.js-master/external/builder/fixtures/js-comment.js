'use strict';
//#if TRUE
////var a;
//var b;
var c;
//#endif
