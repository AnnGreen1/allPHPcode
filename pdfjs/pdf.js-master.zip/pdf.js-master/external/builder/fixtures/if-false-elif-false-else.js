'use strict';
//#if FALSE
var a;
//#elif FALSE
var b;
//#else
var c;
//#endif
