'use strict';
//#if notdefined
var a;
//#else
var b;
//#endif
