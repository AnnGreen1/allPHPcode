import { Test } from 'import-name';
import { Test2 } from './non-alias';
export {
 Test3
} from 'import-name';
var Imp = require('import-name');
var Imp2 = require('./non-alias');
